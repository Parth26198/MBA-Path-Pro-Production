-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: mba_admission_db
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `colleges`
--

DROP TABLE IF EXISTS `colleges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `colleges` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `logo_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cover_banner_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `location` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ranking` int DEFAULT NULL,
  `fees_min` decimal(12,2) DEFAULT NULL,
  `fees_max` decimal(12,2) DEFAULT NULL,
  `avg_package` decimal(12,2) DEFAULT NULL,
  `highest_package` decimal(12,2) DEFAULT NULL,
  `eligibility` text COLLATE utf8mb4_unicode_ci,
  `accepted_exams` json DEFAULT NULL,
  `deadlines` json DEFAULT NULL,
  `admission_process` text COLLATE utf8mb4_unicode_ci,
  `website` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_email` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('draft','pending_approval','published','archived','rejected') COLLATE utf8mb4_unicode_ci DEFAULT 'draft',
  `is_featured` tinyint(1) DEFAULT '0',
  `created_by_trainer_id` int DEFAULT NULL,
  `approved_by_admin_id` int DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `created_by_trainer_id` (`created_by_trainer_id`),
  KEY `approved_by_admin_id` (`approved_by_admin_id`),
  KEY `idx_colleges_status` (`status`),
  KEY `idx_colleges_featured` (`is_featured`),
  CONSTRAINT `colleges_ibfk_1` FOREIGN KEY (`created_by_trainer_id`) REFERENCES `trainers` (`id`) ON DELETE SET NULL,
  CONSTRAINT `colleges_ibfk_2` FOREIGN KEY (`approved_by_admin_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `colleges`
--

LOCK TABLES `colleges` WRITE;
/*!40000 ALTER TABLE `colleges` DISABLE KEYS */;
INSERT INTO `colleges` VALUES (1,'IIM Ahmedabad','iim-ahmedabad','/images/colleges/iim-ahmedabad-logo.png','/images/colleges/iim-ahmedabad-banner.jpg','Indian Institute of Management Ahmedabad is India\'s premier business school, renowned for its rigorous PGP program and exceptional placement record.','Ahmedabad, Gujarat','Ahmedabad','Gujarat',1,2300000.00,2500000.00,33600000.00,150000000.00,'Bachelor\'s degree with 50% marks. Valid CAT score with 99+ percentile preferred.','[\"CAT\"]','{\"final\": \"2025-03-30\", \"round1\": \"2025-01-15\"}','Online application → Shortlist → WAT/GD → PI → Final offer','https://www.iimahmedabad.edu.in','admissions@iim.edu.in','+91 20 1234 5678','published',1,1,1,'2026-05-22 12:54:14','2026-05-22 12:54:14','2026-05-22 12:54:14'),(2,'IIM Bangalore','iim-bangalore','/images/colleges/iim-bangalore-logo.png','/images/colleges/iim-bangalore-banner.jpg','IIM Bangalore offers world-class management education in the heart of India\'s tech capital with strong industry connections.','Bangalore, Karnataka','Bangalore','Karnataka',2,2400000.00,2600000.00,33100000.00,120000000.00,'Graduation with minimum 50%. CAT/GMAT required.','[\"CAT\", \"GMAT\"]','{\"final\": \"2025-03-30\", \"round1\": \"2025-01-15\"}','Online application → Shortlist → WAT/GD → PI → Final offer','https://www.iimbangalore.edu.in','admissions@iim.edu.in','+91 20 1234 5678','published',1,1,1,'2026-05-22 12:54:14','2026-05-22 12:54:14','2026-05-22 12:54:14'),(3,'SP Jain Institute of Management','sp-jain-mumbai','/images/colleges/sp-jain-mumbai-logo.png','/images/colleges/sp-jain-mumbai-banner.jpg','SPJIMR Mumbai is known for its values-driven leadership programs and excellent corporate placements in finance and consulting.','Mumbai, Maharashtra','Mumbai','Maharashtra',8,2200000.00,2400000.00,28500000.00,75000000.00,'Bachelor\'s degree. CAT/XAT/GMAT accepted.','[\"CAT\", \"XAT\", \"GMAT\"]','{\"final\": \"2025-03-30\", \"round1\": \"2025-01-15\"}','Online application → Shortlist → WAT/GD → PI → Final offer','https://www.spjainmumbai.edu.in','admissions@sp.edu.in','+91 20 1234 5678','published',1,1,1,'2026-05-22 12:54:14','2026-05-22 12:54:14','2026-05-22 12:54:14'),(4,'ISB Hyderabad','isb-hyderabad','/images/colleges/isb-hyderabad-logo.png','/images/colleges/isb-hyderabad-banner.jpg','Indian School of Business offers a world-class one-year PGP program with global faculty and unmatched peer group.','Hyderabad, Telangana','Hyderabad','Telangana',3,4100000.00,4500000.00,34800000.00,130000000.00,'2+ years work experience. GMAT/GRE/CAT required.','[\"GMAT\", \"GRE\", \"CAT\"]','{\"final\": \"2025-03-30\", \"round1\": \"2025-01-15\"}','Online application → Shortlist → WAT/GD → PI → Final offer','https://www.isbhyderabad.edu.in','admissions@isb.edu.in','+91 20 1234 5678','published',1,1,1,'2026-05-22 12:54:14','2026-05-22 12:54:14','2026-05-22 12:54:14'),(5,'NMIMS Mumbai','nmims-mumbai','/images/colleges/nmims-mumbai-logo.png','/images/colleges/nmims-mumbai-banner.jpg','NMIMS School of Business Management offers industry-aligned MBA programs with strong Mumbai corporate network.','Mumbai, Maharashtra','Mumbai','Maharashtra',15,2100000.00,2300000.00,24200000.00,55000000.00,'Graduation 50%+. NMAT by GMAC required.','[\"NMAT\"]','{\"final\": \"2025-03-30\", \"round1\": \"2025-01-15\"}','Online application → Shortlist → WAT/GD → PI → Final offer','https://www.nmimsmumbai.edu.in','admissions@nmims.edu.in','+91 20 1234 5678','published',0,1,1,'2026-05-22 12:54:14','2026-05-22 12:54:14','2026-05-22 12:54:14'),(6,'Symbiosis Institute Pune','symbiosis-pune','/images/colleges/symbiosis-pune-logo.png','/images/colleges/symbiosis-pune-banner.jpg','SCMHRD Pune is among India\'s top HR and general management institutes with excellent industry interface.','Pune, Maharashtra','Pune','Maharashtra',18,1800000.00,2000000.00,21500000.00,45000000.00,'Bachelor\'s degree. SNAP test required.','[\"SNAP\"]','{\"final\": \"2025-03-30\", \"round1\": \"2025-01-15\"}','Online application → Shortlist → WAT/GD → PI → Final offer','https://www.symbiosispune.edu.in','admissions@symbiosis.edu.in','+91 20 1234 5678','published',0,1,1,'2026-05-22 12:54:14','2026-05-22 12:54:14','2026-05-22 12:54:14'),(7,'CRUD College 1781592207207','crud-college-1781592207207',NULL,NULL,NULL,NULL,'Mumbai',NULL,NULL,100000.00,200000.00,NULL,NULL,NULL,'[]','{}',NULL,NULL,NULL,NULL,'published',0,1,1,'2026-06-16 07:08:12','2026-06-16 06:43:27','2026-06-16 07:08:12'),(8,'CRUD College 1781701131315','crud-college-1781701131315',NULL,NULL,NULL,NULL,'Mumbai',NULL,NULL,100000.00,200000.00,NULL,NULL,NULL,'[]','{}',NULL,NULL,NULL,NULL,'draft',0,1,NULL,NULL,'2026-06-17 12:58:51','2026-06-17 12:58:51');
/*!40000 ALTER TABLE `colleges` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-24 18:37:37
