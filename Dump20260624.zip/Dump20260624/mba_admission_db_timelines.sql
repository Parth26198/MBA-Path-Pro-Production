-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: mba_admission_db
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `timelines`
--

DROP TABLE IF EXISTS `timelines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `timelines` (
  `id` int NOT NULL AUTO_INCREMENT,
  `application_id` int DEFAULT NULL,
  `student_id` int NOT NULL,
  `actor_user_id` int DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `event_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'general',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `actor_user_id` (`actor_user_id`),
  KEY `idx_timeline_student` (`student_id`),
  KEY `idx_timeline_app` (`application_id`),
  CONSTRAINT `timelines_ibfk_1` FOREIGN KEY (`application_id`) REFERENCES `applications` (`id`) ON DELETE CASCADE,
  CONSTRAINT `timelines_ibfk_2` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  CONSTRAINT `timelines_ibfk_3` FOREIGN KEY (`actor_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `timelines`
--

LOCK TABLES `timelines` WRITE;
/*!40000 ALTER TABLE `timelines` DISABLE KEYS */;
INSERT INTO `timelines` VALUES (1,1,1,2,'SOP corrected by trainer','Trainer reviewed and improved SOP structure and impact statements','application','2026-05-22 12:54:14'),(2,1,1,2,'Resume reviewed','Resume optimized for IIM A format with quantified achievements','application','2026-05-22 12:54:14'),(3,1,1,2,'Documents verified','All mandatory documents verified and approved','application','2026-05-22 12:54:14'),(4,2,1,2,'Trainer assigned GD questions','15 GD topics shared for SPJIMR pattern practice','application','2026-05-22 12:54:14'),(5,2,1,2,'Mock GD completed','Student performed well in mock GD with 7.5/10 rating','application','2026-05-22 12:54:14'),(6,2,1,2,'Confidence improvement suggested','Recommended daily speaking practice for 15 minutes','application','2026-05-22 12:54:14'),(7,3,1,2,'Trainer requested missing documents','SOP draft and official transcript required for ISB application','application','2026-05-22 12:54:14'),(8,3,1,2,'Student notified','Notification sent to upload pending documents within 48 hours','application','2026-05-22 12:54:14'),(9,4,1,3,'Application initiated','Student started application to IIM Bangalore','application','2026-06-15 08:01:41'),(10,4,1,2,'Status updated to Under Review','Application status changed from Draft to Under Review','status','2026-06-15 08:01:41'),(11,4,1,2,'Trainer remarks updated','Audit remarks 1781510501852','remarks','2026-06-15 08:01:41'),(12,4,1,2,'Audit timeline','E2E test','general','2026-06-15 08:01:41'),(13,4,1,2,'Checklist completed: Form Filled','Marked complete by trainer','checklist','2026-06-15 08:01:41'),(14,5,1,3,'Application initiated','Student started application to NMIMS Mumbai','application','2026-06-15 08:08:10'),(15,5,1,2,'Status updated to GDPI Preparation','Application status changed from Draft to GDPI Preparation','status','2026-06-15 08:08:10'),(16,5,1,2,'Trainer remarks updated','Demo ready 1781510890070','remarks','2026-06-15 08:08:10'),(17,5,1,2,'Demo timeline','ok','general','2026-06-15 08:08:10'),(18,5,1,2,'RC Timeline Event','Smoke test timeline','update','2026-06-15 09:40:49'),(19,5,1,2,'RC Timeline Event','Smoke test timeline','update','2026-06-15 09:41:19'),(20,5,1,2,'RC Timeline Event','Smoke test timeline','update','2026-06-15 09:41:56'),(21,5,1,2,'Status updated to Documents Pending','Application status changed from GDPI Preparation to Documents Pending','status','2026-06-16 06:08:29'),(22,5,1,2,'Status updated to Under Review','Application status changed from Documents Pending to Under Review','status','2026-06-16 06:08:42'),(23,5,1,2,'Trainer remarks updated','test','remarks','2026-06-16 06:08:51'),(24,5,1,2,'Checklist completed: Form Filled','Marked complete by trainer','checklist','2026-06-16 06:08:55'),(25,5,1,2,'Checklist completed: Mock Interview Pending','Marked complete by trainer','checklist','2026-06-16 06:09:11'),(26,5,1,2,'Checklist completed: SOP Uploaded','Marked complete by trainer','checklist','2026-06-16 06:09:16'),(27,5,1,2,'Checklist completed: Transcript Uploaded','Marked complete by trainer','checklist','2026-06-16 06:09:16'),(28,5,1,2,'done','done','general','2026-06-16 06:09:24'),(29,5,1,2,'Checklist completed: Resume Uploaded','Marked complete by trainer','checklist','2026-06-16 06:09:30'),(30,5,1,2,'Checklist completed: Fees Paid','Marked complete by trainer','checklist','2026-06-16 06:09:32'),(31,6,1,3,'Application initiated','Student started application to Symbiosis Institute Pune','application','2026-06-16 06:11:09'),(32,6,1,2,'RC Timeline Event','Smoke test timeline','update','2026-06-16 06:44:15'),(33,7,18,22,'Application initiated','Student started application to CRUD College 1781592207207','application','2026-06-16 07:13:10'),(34,7,18,2,'Status updated to Documents Pending','Application status changed from Draft to Documents Pending','status','2026-06-16 07:14:32'),(35,7,18,2,'Trainer remarks updated','test ','remarks','2026-06-16 07:14:32'),(36,7,18,2,'Checklist completed: Form Filled','Marked complete by trainer','checklist','2026-06-16 07:14:34'),(37,7,18,2,'Checklist completed: Resume Uploaded','Marked complete by trainer','checklist','2026-06-16 07:14:35'),(38,7,18,2,'Checklist completed: SOP Uploaded','Marked complete by trainer','checklist','2026-06-16 07:14:37'),(39,7,18,2,'Checklist completed: Fees Paid','Marked complete by trainer','checklist','2026-06-16 07:14:38');
/*!40000 ALTER TABLE `timelines` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-24 18:37:37
