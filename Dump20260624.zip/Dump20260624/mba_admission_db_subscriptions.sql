-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: mba_admission_db
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `subscriptions`
--

DROP TABLE IF EXISTS `subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subscriptions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `student_id` int NOT NULL,
  `package_id` int NOT NULL,
  `payment_id` int DEFAULT NULL,
  `status` enum('pending','active','expired','cancelled') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `college_limit` int NOT NULL,
  `starts_at` datetime DEFAULT NULL,
  `ends_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `package_id` (`package_id`),
  KEY `payment_id` (`payment_id`),
  KEY `idx_subscriptions_student_status` (`student_id`,`status`),
  CONSTRAINT `subscriptions_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  CONSTRAINT `subscriptions_ibfk_2` FOREIGN KEY (`package_id`) REFERENCES `packages` (`id`),
  CONSTRAINT `subscriptions_ibfk_3` FOREIGN KEY (`payment_id`) REFERENCES `payments` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscriptions`
--

LOCK TABLES `subscriptions` WRITE;
/*!40000 ALTER TABLE `subscriptions` DISABLE KEYS */;
INSERT INTO `subscriptions` VALUES (1,15,1,NULL,'active',5,'2026-06-24 14:01:27',NULL,'2026-06-24 08:31:27','2026-06-24 08:31:27'),(2,18,1,7,'active',5,'2026-06-16 12:42:54',NULL,'2026-06-24 08:31:27','2026-06-24 08:31:27'),(3,19,1,NULL,'active',5,'2026-06-24 14:01:27',NULL,'2026-06-24 08:31:27','2026-06-24 08:31:27'),(4,22,1,8,'active',5,'2026-06-17 18:35:27',NULL,'2026-06-24 08:31:27','2026-06-24 08:31:27'),(5,1,2,6,'cancelled',7,'2026-06-16 12:14:16',NULL,'2026-06-24 08:31:27','2026-06-24 10:06:48'),(6,1,2,5,'cancelled',7,'2026-06-15 15:11:19',NULL,'2026-06-24 08:31:27','2026-06-24 10:06:48'),(7,1,2,4,'cancelled',7,'2026-06-15 15:10:01',NULL,'2026-06-24 08:31:27','2026-06-24 10:06:48'),(8,1,2,3,'cancelled',7,'2026-06-15 15:09:13',NULL,'2026-06-24 08:31:27','2026-06-24 10:06:48'),(9,1,2,1,'cancelled',7,'2026-05-22 18:24:14',NULL,'2026-06-24 08:31:27','2026-06-24 10:06:48'),(10,2,2,2,'active',7,'2026-06-15 13:55:45',NULL,'2026-06-24 08:31:27','2026-06-24 08:31:27'),(16,1,3,9,'active',10,'2026-06-24 15:36:48',NULL,'2026-06-24 10:06:48','2026-06-24 10:06:48');
/*!40000 ALTER TABLE `subscriptions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-24 18:37:36
