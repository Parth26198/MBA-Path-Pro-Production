-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: mba_admission_db
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expires_at` datetime NOT NULL,
  `used_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `token` (`token`),
  KEY `user_id` (`user_id`),
  KEY `idx_reset_token` (`token`),
  CONSTRAINT `password_reset_tokens_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
INSERT INTO `password_reset_tokens` VALUES (1,3,'e7ad924a6e57671fbb7b905b7a2bad3c53f23f29881e20e90865e6fd84c832a5','2026-06-15 16:09:14',NULL,'2026-06-15 09:39:13'),(2,3,'645df53c9b221fed7dc2a0ed8ed5dff5ee5a9f3ebbafd9f5d7b985bb86783728','2026-06-15 16:10:01',NULL,'2026-06-15 09:40:00'),(3,3,'24879cdd1760c28f0f9ad9d1e3300d925ee556a16dce53957e145c08845ed9f2','2026-06-15 16:10:50','2026-06-15 15:10:50','2026-06-15 09:40:49'),(4,3,'9687acd57810b91b1b16e1f6a6e90780c94c261168f666e88e90a0516f9ea3da','2026-06-15 16:11:19','2026-06-15 15:11:19','2026-06-15 09:41:19'),(5,3,'7dd007174d25f8004952f59a07547c4f8febf736f712d7eeed8212c960edc286','2026-06-15 16:11:20',NULL,'2026-06-15 09:41:19'),(6,3,'0afd8cb8ab12d49cd22c260335936fbf2a4e302319ea97f5c5fb17f5b2147964','2026-06-15 16:11:56','2026-06-15 15:11:56','2026-06-15 09:41:56'),(7,3,'3c8be16f434ac3bf1b90dd5bb2a69069e42ef01e01b6196549295fd995eccbdc','2026-06-16 13:14:15',NULL,'2026-06-16 06:44:15'),(8,3,'875eb29bba490a758a20a1100ce0918f1ee8baf2c4750bb7eb9e77cd71693786','2026-06-16 13:14:16','2026-06-16 12:14:16','2026-06-16 06:44:15');
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-24 18:37:38
