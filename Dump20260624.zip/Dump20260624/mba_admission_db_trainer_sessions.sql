-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: mba_admission_db
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `trainer_sessions`
--

DROP TABLE IF EXISTS `trainer_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `trainer_sessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `student_id` int NOT NULL,
  `trainer_id` int NOT NULL,
  `session_type` enum('google_meet','phone_call','mock_interview','gd_practice','counseling') COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scheduled_at` datetime DEFAULT NULL,
  `duration_minutes` int DEFAULT '60',
  `status` enum('scheduled','completed','cancelled','no_show') COLLATE utf8mb4_unicode_ci DEFAULT 'scheduled',
  `meet_link` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `remarks` text COLLATE utf8mb4_unicode_ci,
  `progress_rating` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `attendance` enum('scheduled','present','absent','late','excused') COLLATE utf8mb4_unicode_ci DEFAULT 'scheduled',
  PRIMARY KEY (`id`),
  KEY `idx_session_student` (`student_id`),
  KEY `idx_session_trainer` (`trainer_id`),
  CONSTRAINT `trainer_sessions_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  CONSTRAINT `trainer_sessions_ibfk_2` FOREIGN KEY (`trainer_id`) REFERENCES `trainers` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trainer_sessions`
--

LOCK TABLES `trainer_sessions` WRITE;
/*!40000 ALTER TABLE `trainer_sessions` DISABLE KEYS */;
INSERT INTO `trainer_sessions` VALUES (1,1,1,'google_meet','Profile Review & College Shortlisting','2026-05-08 18:24:15',90,'completed','https://meet.google.com/abc-defg-hij','Reviewed profile and shortlisted 7 target colleges','Student has strong academic profile',8,'2026-05-22 12:54:15','2026-05-22 12:54:15','scheduled'),(2,1,1,'mock_interview','IIM A Mock Personal Interview','2026-05-15 18:24:15',60,'completed',NULL,'Conducted full PI simulation with feedback','Needs improvement in Why MBA answer',6,'2026-05-22 12:54:15','2026-05-22 12:54:15','scheduled'),(3,1,1,'gd_practice','SPJIMR GD Mock Session','2026-05-19 18:24:15',75,'completed','https://meet.google.com/xyz-uvwx-rst','Group discussion on AI in education','Good content, moderate leadership',7,'2026-05-22 12:54:15','2026-05-22 12:54:15','scheduled'),(4,1,1,'google_meet','ISB Application Strategy','2026-05-24 18:24:15',60,'scheduled','https://meet.google.com/pqr-stuv-wxy','Plan ISB application timeline',NULL,NULL,'2026-05-22 12:54:15','2026-05-22 12:54:15','scheduled'),(5,1,1,'google_meet','RC Smoke Session','2026-06-16 09:40:01',60,'scheduled','https://meet.google.com/rc-smoke',NULL,NULL,NULL,'2026-06-15 09:40:01','2026-06-15 09:40:01','scheduled'),(6,1,1,'google_meet','RC Smoke Session','2026-06-16 09:41:19',60,'scheduled','https://meet.google.com/rc-smoke',NULL,NULL,NULL,'2026-06-15 09:41:19','2026-06-15 09:41:19','scheduled'),(7,1,1,'google_meet','RC Smoke Session','2026-06-17 06:44:16',60,'scheduled','https://meet.google.com/rc-smoke',NULL,NULL,NULL,'2026-06-16 06:44:16','2026-06-16 06:44:16','scheduled');
/*!40000 ALTER TABLE `trainer_sessions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-24 18:37:38
