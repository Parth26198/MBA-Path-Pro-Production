-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: mba_admission_db
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `students`
--

DROP TABLE IF EXISTS `students`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `students` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `package_id` int DEFAULT NULL,
  `trainer_id` int DEFAULT NULL,
  `colleges_allowed` int DEFAULT '0',
  `colleges_applied` int DEFAULT '0',
  `enrollment_date` date DEFAULT NULL,
  `payment_status` enum('pending','completed','failed') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `status` enum('active','inactive','completed') COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `city` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `linkedin_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `career_goal` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `degree` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `university` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `graduation_year` int DEFAULT NULL,
  `work_experience_years` int DEFAULT '0',
  `target_exams` json DEFAULT NULL,
  `onboarding_step` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT 'completed',
  `onboarding_completed_at` timestamp NULL DEFAULT NULL,
  `target_countries` json DEFAULT NULL,
  `academic_details` json DEFAULT NULL,
  `work_experience` json DEFAULT NULL,
  `target_programs` json DEFAULT NULL,
  `preferred_budget_max` decimal(12,2) DEFAULT NULL,
  `onboarding_completed` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  KEY `idx_students_trainer` (`trainer_id`),
  KEY `idx_students_package` (`package_id`),
  CONSTRAINT `students_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `students_ibfk_2` FOREIGN KEY (`package_id`) REFERENCES `packages` (`id`),
  CONSTRAINT `students_ibfk_3` FOREIGN KEY (`trainer_id`) REFERENCES `trainers` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `students`
--

LOCK TABLES `students` WRITE;
/*!40000 ALTER TABLE `students` DISABLE KEYS */;
INSERT INTO `students` VALUES (1,3,3,1,10,6,'2026-05-22','completed','active','2026-05-22 12:54:14','2026-06-24 10:06:48','Pune','Maharashtra',NULL,'it',NULL,NULL,NULL,0,NULL,'8',NULL,'[\"India\"]','{\"gmat\": 123, \"cat_percentile\": 11}',NULL,'[\"it\"]',250000.00,1),(2,4,2,NULL,7,0,'2026-06-15','completed','active','2026-06-15 08:25:45','2026-06-24 09:16:52',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'8',NULL,NULL,NULL,NULL,NULL,NULL,1),(3,5,NULL,NULL,0,0,'2026-06-15','pending','active','2026-06-15 09:40:49','2026-06-24 09:16:52',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'8',NULL,NULL,NULL,NULL,NULL,NULL,1),(4,6,NULL,NULL,0,0,'2026-06-15','pending','active','2026-06-15 09:41:19','2026-06-24 09:16:52',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'8',NULL,NULL,NULL,NULL,NULL,NULL,1),(5,7,NULL,1,0,0,'2026-06-15','pending','active','2026-06-15 09:41:56','2026-06-24 09:16:52',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'8',NULL,NULL,NULL,NULL,NULL,NULL,1),(6,8,NULL,1,0,0,'2026-06-16','pending','inactive','2026-06-16 06:05:10','2026-06-24 09:16:52',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'8',NULL,NULL,NULL,NULL,NULL,NULL,1),(7,10,NULL,NULL,0,0,'2026-06-16','pending','active','2026-06-16 06:17:27','2026-06-24 09:16:52',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'8',NULL,NULL,NULL,NULL,NULL,NULL,1),(8,11,NULL,NULL,0,0,'2026-06-16','pending','active','2026-06-16 06:22:55','2026-06-24 09:16:52',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'8',NULL,NULL,NULL,NULL,NULL,NULL,1),(9,12,NULL,NULL,0,0,'2026-06-16','pending','active','2026-06-16 06:25:42','2026-06-24 09:16:52',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'8',NULL,NULL,NULL,NULL,NULL,NULL,1),(10,13,NULL,NULL,0,0,'2026-06-16','pending','active','2026-06-16 06:28:48','2026-06-24 09:16:52',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'8',NULL,NULL,NULL,NULL,NULL,NULL,1),(11,14,NULL,NULL,0,0,'2026-06-16','pending','active','2026-06-16 06:28:52','2026-06-24 09:16:52',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'8',NULL,NULL,NULL,NULL,NULL,NULL,1),(12,15,NULL,NULL,0,0,'2026-06-16','pending','active','2026-06-16 06:29:52','2026-06-24 09:16:52',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'8',NULL,NULL,NULL,NULL,NULL,NULL,1),(13,16,NULL,NULL,0,0,'2026-06-16','pending','active','2026-06-16 06:31:04','2026-06-24 09:16:52',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'8',NULL,NULL,NULL,NULL,NULL,NULL,1),(14,17,NULL,NULL,0,0,'2026-06-16','pending','active','2026-06-16 06:35:58','2026-06-24 09:16:52',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'8',NULL,NULL,NULL,NULL,NULL,NULL,1),(15,19,1,1,5,0,'2026-06-16','completed','active','2026-06-16 06:43:27','2026-06-24 09:16:52',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'8',NULL,NULL,NULL,NULL,NULL,NULL,1),(16,20,NULL,1,0,0,'2026-06-16','pending','active','2026-06-16 06:43:27','2026-06-24 09:16:52',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'8',NULL,NULL,NULL,NULL,NULL,NULL,1),(17,21,NULL,1,0,0,'2026-06-16','pending','inactive','2026-06-16 06:44:15','2026-06-24 09:16:52',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'8',NULL,NULL,NULL,NULL,NULL,NULL,1),(18,22,1,1,5,1,'2026-06-16','completed','active','2026-06-16 07:12:45','2026-06-24 09:16:52',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'8',NULL,NULL,NULL,NULL,NULL,NULL,1),(19,24,1,NULL,5,0,'2026-06-17','completed','active','2026-06-17 12:58:51','2026-06-24 09:16:52',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'8','2026-06-17 12:58:51',NULL,NULL,NULL,NULL,NULL,1),(20,25,1,NULL,0,0,'2026-06-17','pending','active','2026-06-17 12:58:51','2026-06-24 09:16:52',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'8',NULL,NULL,NULL,NULL,NULL,NULL,1),(21,26,1,NULL,0,0,'2026-06-17','pending','active','2026-06-17 12:58:51','2026-06-24 09:16:52','Mumbai','Maharashtra',NULL,'Product Management',NULL,NULL,NULL,0,NULL,'8',NULL,NULL,NULL,NULL,NULL,NULL,1),(22,27,1,NULL,5,0,'2026-06-17','completed','active','2026-06-17 13:04:41','2026-06-24 09:16:52','pune','pune',NULL,'MBA','B.Tech','MSBTE',2026,2,'[\"CAT\", \"XAT\", \"GMAT\", \"MAT\"]','8','2026-06-17 13:05:27',NULL,NULL,NULL,NULL,NULL,1),(23,28,NULL,NULL,0,0,'2026-06-24','pending','active','2026-06-24 10:11:13','2026-06-24 10:17:17',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'8',NULL,'[\"India\"]',NULL,NULL,NULL,NULL,1),(24,29,NULL,NULL,0,0,'2026-06-24','pending','active','2026-06-24 10:32:44','2026-06-24 10:32:45',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'8',NULL,NULL,NULL,NULL,NULL,NULL,1),(25,30,NULL,NULL,0,0,'2026-06-24','pending','active','2026-06-24 10:33:42','2026-06-24 10:39:01',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'8',NULL,NULL,NULL,NULL,NULL,NULL,1),(26,31,NULL,NULL,0,0,'2026-06-24','pending','active','2026-06-24 10:47:30','2026-06-24 10:47:31',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'10',NULL,NULL,NULL,NULL,NULL,NULL,1),(27,32,NULL,NULL,0,0,'2026-06-24','pending','active','2026-06-24 10:54:44','2026-06-24 11:26:26',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'8',NULL,NULL,NULL,NULL,NULL,NULL,1),(28,33,NULL,NULL,0,0,'2026-06-24','pending','active','2026-06-24 10:56:45','2026-06-24 11:26:26',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'8',NULL,'[\"India\"]',NULL,NULL,NULL,NULL,1),(29,34,NULL,NULL,0,0,'2026-06-24','pending','active','2026-06-24 10:57:12','2026-06-24 10:58:28',NULL,NULL,NULL,'Product',NULL,NULL,NULL,0,NULL,'10',NULL,'[\"India\"]','{\"gpa\": \"9.5\", \"gmat\": null, \"degree\": \"B.Tech / B.E.\", \"cat_status\": \"planned\", \"percentage\": \"9.5\", \"gmat_status\": \"planned\", \"cat_percentile\": null, \"graduation_year\": \"2026\"}','{\"years\": \"3-5\", \"current_role\": \"Flutter \"}','[\"Full Time MBA\"]',4000000.00,1);
/*!40000 ALTER TABLE `students` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-24 18:37:37
