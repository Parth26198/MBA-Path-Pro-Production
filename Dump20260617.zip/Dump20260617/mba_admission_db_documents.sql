-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: mba_admission_db
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `documents`
--

DROP TABLE IF EXISTS `documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `documents` (
  `id` int NOT NULL AUTO_INCREMENT,
  `student_id` int NOT NULL,
  `uploaded_by_user_id` int NOT NULL,
  `application_id` int DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_url` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_size` int DEFAULT NULL,
  `category` enum('sop','resume','transcript','lor','other') COLLATE utf8mb4_unicode_ci DEFAULT 'other',
  `status` enum('pending','verified','rejected') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `rejection_reason` text COLLATE utf8mb4_unicode_ci,
  `verified_by_user_id` int DEFAULT NULL,
  `verified_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `student_id` (`student_id`),
  KEY `uploaded_by_user_id` (`uploaded_by_user_id`),
  KEY `application_id` (`application_id`),
  CONSTRAINT `documents_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  CONSTRAINT `documents_ibfk_2` FOREIGN KEY (`uploaded_by_user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `documents_ibfk_3` FOREIGN KEY (`application_id`) REFERENCES `applications` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents`
--

LOCK TABLES `documents` WRITE;
/*!40000 ALTER TABLE `documents` DISABLE KEYS */;
INSERT INTO `documents` VALUES (1,1,3,1,'Statement of Purpose - IIM A','/uploads/documents/sop-iim-a.pdf','application/pdf',NULL,'sop','verified','2026-05-22 12:54:15',NULL,NULL,NULL,'2026-06-15 09:37:07'),(2,1,3,1,'Resume - Updated','/uploads/documents/resume-paresh.pdf','application/pdf',NULL,'resume','verified','2026-05-22 12:54:15',NULL,NULL,NULL,'2026-06-15 09:37:07'),(3,1,3,NULL,'Transcript - Pending','/uploads/documents/transcript-pending.pdf','application/pdf',NULL,'transcript','pending','2026-05-22 12:54:15',NULL,NULL,NULL,'2026-06-15 09:37:07'),(4,1,3,NULL,'RC Test Resume','/uploads/documents/1781516449766-596984482.pdf','application/pdf',25,'resume','pending','2026-06-15 09:40:49',NULL,NULL,NULL,'2026-06-15 09:40:49'),(5,1,3,NULL,'RC Test Resume','/uploads/documents/1781516479035-985663145.pdf','application/pdf',25,'resume','verified','2026-06-15 09:41:19',NULL,2,'2026-06-15 09:41:19','2026-06-15 09:41:19'),(6,1,3,NULL,'RC Test Resume','/uploads/documents/1781516515902-134590139.pdf','application/pdf',25,'resume','verified','2026-06-15 09:41:55',NULL,2,'2026-06-15 09:41:55','2026-06-15 09:41:55'),(7,1,3,NULL,'RC Test Resume','/uploads/documents/1781592255184-46699831.pdf','application/pdf',25,'resume','verified','2026-06-16 06:44:15',NULL,2,'2026-06-16 06:44:15','2026-06-16 06:44:15');
/*!40000 ALTER TABLE `documents` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-17 11:31:59
