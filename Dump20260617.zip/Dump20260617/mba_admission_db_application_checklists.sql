-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: mba_admission_db
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `application_checklists`
--

DROP TABLE IF EXISTS `application_checklists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `application_checklists` (
  `id` int NOT NULL AUTO_INCREMENT,
  `application_id` int NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_completed` tinyint(1) DEFAULT '0',
  `completed_by_trainer` tinyint(1) DEFAULT '0',
  `completed_at` timestamp NULL DEFAULT NULL,
  `sort_order` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_checklist_app` (`application_id`),
  CONSTRAINT `application_checklists_ibfk_1` FOREIGN KEY (`application_id`) REFERENCES `applications` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `application_checklists`
--

LOCK TABLES `application_checklists` WRITE;
/*!40000 ALTER TABLE `application_checklists` DISABLE KEYS */;
INSERT INTO `application_checklists` VALUES (1,1,'Form Filled',1,1,'2026-05-22 12:54:14',0),(2,1,'SOP Uploaded',1,1,'2026-05-22 12:54:14',1),(3,1,'Resume Uploaded',1,1,'2026-05-22 12:54:14',2),(4,1,'Fees Paid',1,1,'2026-05-22 12:54:14',3),(5,1,'Mock Interview Pending',0,0,NULL,4),(6,2,'Form Filled',1,1,'2026-05-22 12:54:14',0),(7,2,'SOP Uploaded',1,1,'2026-05-22 12:54:14',1),(8,2,'GD Practice Completed',1,1,'2026-05-22 12:54:14',2),(9,2,'Interview Practice Pending',0,0,NULL,3),(10,3,'Resume Uploaded',1,1,'2026-05-22 12:54:14',0),(11,3,'SOP Pending',0,0,NULL,1),(12,3,'Transcript Pending',0,0,NULL,2),(13,4,'Form Filled',1,1,'2026-06-15 08:01:41',0),(14,4,'SOP Uploaded',0,0,NULL,1),(15,4,'Resume Uploaded',0,0,NULL,2),(16,4,'Transcript Uploaded',0,0,NULL,3),(17,4,'Fees Paid',0,0,NULL,4),(18,4,'Mock Interview Pending',0,0,NULL,5),(19,5,'Form Filled',1,1,'2026-06-16 06:08:55',0),(20,5,'SOP Uploaded',1,1,'2026-06-16 06:09:16',1),(21,5,'Resume Uploaded',1,1,'2026-06-16 06:09:30',2),(22,5,'Transcript Uploaded',1,1,'2026-06-16 06:09:16',3),(23,5,'Fees Paid',1,1,'2026-06-16 06:09:32',4),(24,5,'Mock Interview Pending',1,1,'2026-06-16 06:09:11',5),(25,6,'Form Filled',0,0,NULL,0),(26,6,'SOP Uploaded',0,0,NULL,1),(27,6,'Resume Uploaded',0,0,NULL,2),(28,6,'Transcript Uploaded',0,0,NULL,3),(29,6,'Fees Paid',0,0,NULL,4),(30,6,'Mock Interview Pending',0,0,NULL,5),(31,7,'Form Filled',1,1,'2026-06-16 07:14:34',0),(32,7,'SOP Uploaded',1,1,'2026-06-16 07:14:37',1),(33,7,'Resume Uploaded',1,1,'2026-06-16 07:14:35',2),(34,7,'Transcript Uploaded',0,0,NULL,3),(35,7,'Fees Paid',1,1,'2026-06-16 07:14:38',4),(36,7,'Mock Interview Pending',0,0,NULL,5);
/*!40000 ALTER TABLE `application_checklists` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-17 11:31:59
