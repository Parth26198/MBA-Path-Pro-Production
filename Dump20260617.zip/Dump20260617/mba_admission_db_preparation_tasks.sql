-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: mba_admission_db
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `preparation_tasks`
--

DROP TABLE IF EXISTS `preparation_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `preparation_tasks` (
  `id` int NOT NULL AUTO_INCREMENT,
  `student_id` int NOT NULL,
  `trainer_id` int NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `task_type` enum('pdf','video','interview','gd','assignment','other') COLLATE utf8mb4_unicode_ci DEFAULT 'other',
  `resource_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('assigned','in_progress','completed','verified') COLLATE utf8mb4_unicode_ci DEFAULT 'assigned',
  `trainer_remarks` text COLLATE utf8mb4_unicode_ci,
  `confidence_score` int DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `verified_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `student_notes` text COLLATE utf8mb4_unicode_ci,
  `student_completed_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `trainer_id` (`trainer_id`),
  KEY `idx_prep_student` (`student_id`),
  CONSTRAINT `preparation_tasks_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  CONSTRAINT `preparation_tasks_ibfk_2` FOREIGN KEY (`trainer_id`) REFERENCES `trainers` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `preparation_tasks`
--

LOCK TABLES `preparation_tasks` WRITE;
/*!40000 ALTER TABLE `preparation_tasks` DISABLE KEYS */;
INSERT INTO `preparation_tasks` VALUES (1,1,1,'MBA HR Interview Questions PDF','Complete HR interview preparation document','pdf','/uploads/resources/hr-interview-questions.pdf','verified','Student answered confidently but needs communication improvement.',7,NULL,'2026-05-22 12:54:14','2026-05-22 12:54:14','2026-05-22 12:54:14',NULL,NULL),(2,1,1,'Watch GD Preparation Video','Complete GD preparation video module','video','/uploads/resources/gd-prep-video.mp4','completed','Student watched only partially.',NULL,NULL,NULL,'2026-05-22 12:54:14','2026-06-16 06:10:39',NULL,'2026-06-16 06:10:39'),(3,1,1,'RC Smoke Task','Test task','other',NULL,'verified',NULL,NULL,NULL,'2026-06-15 09:40:49','2026-06-15 09:40:01','2026-06-15 09:40:49','RC completed','2026-06-15 09:40:49'),(4,1,1,'RC Smoke Task','Test task','other',NULL,'completed',NULL,NULL,NULL,NULL,'2026-06-15 09:41:19','2026-06-16 06:10:49',NULL,'2026-06-16 06:10:49'),(5,1,1,'RC Complete Test','Fresh task','other',NULL,'verified',NULL,NULL,NULL,'2026-06-15 09:41:55','2026-06-15 09:41:55','2026-06-15 09:41:55','RC completed','2026-06-15 09:41:55'),(6,1,1,'test','test','other',NULL,'assigned',NULL,NULL,'2026-06-16',NULL,'2026-06-16 06:14:09','2026-06-16 06:14:09',NULL,NULL),(7,1,1,'RC Complete Test','Fresh task','other',NULL,'verified',NULL,NULL,NULL,'2026-06-16 06:44:15','2026-06-16 06:44:15','2026-06-16 06:44:15','RC completed','2026-06-16 06:44:15'),(8,1,1,'RC Smoke Task','Test task','other',NULL,'assigned',NULL,NULL,NULL,NULL,'2026-06-16 06:44:16','2026-06-16 06:44:16',NULL,NULL);
/*!40000 ALTER TABLE `preparation_tasks` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-17 11:31:59
