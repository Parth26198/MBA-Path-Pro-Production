-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: mba_admission_db
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `students`
--

DROP TABLE IF EXISTS `students`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `students` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `package_id` int DEFAULT NULL,
  `trainer_id` int DEFAULT NULL,
  `colleges_allowed` int DEFAULT '0',
  `colleges_applied` int DEFAULT '0',
  `enrollment_date` date DEFAULT NULL,
  `payment_status` enum('pending','completed','failed') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `status` enum('active','inactive','completed') COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  KEY `idx_students_trainer` (`trainer_id`),
  KEY `idx_students_package` (`package_id`),
  CONSTRAINT `students_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `students_ibfk_2` FOREIGN KEY (`package_id`) REFERENCES `packages` (`id`),
  CONSTRAINT `students_ibfk_3` FOREIGN KEY (`trainer_id`) REFERENCES `trainers` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `students`
--

LOCK TABLES `students` WRITE;
/*!40000 ALTER TABLE `students` DISABLE KEYS */;
INSERT INTO `students` VALUES (1,3,2,1,7,6,'2026-05-22','completed','active','2026-05-22 12:54:14','2026-06-16 06:11:09'),(2,4,2,NULL,7,0,'2026-06-15','completed','active','2026-06-15 08:25:45','2026-06-15 08:25:45'),(3,5,1,NULL,5,0,'2026-06-15','pending','active','2026-06-15 09:40:49','2026-06-15 09:40:49'),(4,6,1,NULL,5,0,'2026-06-15','pending','active','2026-06-15 09:41:19','2026-06-15 09:41:19'),(5,7,1,1,5,0,'2026-06-15','pending','active','2026-06-15 09:41:56','2026-06-16 07:09:18'),(6,8,1,1,5,0,'2026-06-16','pending','inactive','2026-06-16 06:05:10','2026-06-16 07:09:00'),(7,10,1,NULL,5,0,'2026-06-16','pending','active','2026-06-16 06:17:27','2026-06-16 06:17:27'),(8,11,1,NULL,5,0,'2026-06-16','pending','active','2026-06-16 06:22:55','2026-06-16 06:22:55'),(9,12,1,NULL,5,0,'2026-06-16','pending','active','2026-06-16 06:25:42','2026-06-16 06:25:42'),(10,13,1,NULL,5,0,'2026-06-16','pending','active','2026-06-16 06:28:48','2026-06-16 06:28:48'),(11,14,1,NULL,5,0,'2026-06-16','pending','active','2026-06-16 06:28:52','2026-06-16 06:28:52'),(12,15,1,NULL,5,0,'2026-06-16','pending','active','2026-06-16 06:29:52','2026-06-16 06:29:52'),(13,16,1,NULL,5,0,'2026-06-16','pending','active','2026-06-16 06:31:04','2026-06-16 06:31:04'),(14,17,1,NULL,5,0,'2026-06-16','pending','active','2026-06-16 06:35:58','2026-06-16 06:35:58'),(15,19,1,1,5,0,'2026-06-16','completed','active','2026-06-16 06:43:27','2026-06-16 07:08:44'),(16,20,1,1,5,0,'2026-06-16','pending','active','2026-06-16 06:43:27','2026-06-16 07:09:13'),(17,21,1,1,5,0,'2026-06-16','pending','inactive','2026-06-16 06:44:15','2026-06-16 07:08:30'),(18,22,1,1,5,1,'2026-06-16','completed','active','2026-06-16 07:12:45','2026-06-16 07:13:38');
/*!40000 ALTER TABLE `students` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-17 11:31:59
