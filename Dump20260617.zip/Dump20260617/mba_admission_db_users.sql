-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: mba_admission_db
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `role_id` int NOT NULL,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `avatar_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `last_login_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `idx_users_role` (`role_id`),
  KEY `idx_users_email` (`email`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,1,'Yash Patil','yash@admin.com','$2a$10$j7JQ3KBP7tA5gGkApy3U5.DJOmxwUpVJ5tLa13lMR3/L8H3DyZ5yq',NULL,NULL,1,'2026-06-16 07:15:48','2026-05-22 12:54:14','2026-06-16 07:15:48'),(2,2,'Aniket Sharma','aniket@trainer.com','$2a$10$j7JQ3KBP7tA5gGkApy3U5.DJOmxwUpVJ5tLa13lMR3/L8H3DyZ5yq','+91 98765 43210',NULL,1,'2026-06-16 07:13:57','2026-05-22 12:54:14','2026-06-16 07:13:57'),(3,3,'Paresh Dahivelkar','paresh@student.com','$2a$10$iZCQTnNqtQCpHejWbzzZueKdWFUn6VGeqxvaxDHZciyzdsF0vJg8C','+91 91234 56789',NULL,1,'2026-06-16 06:44:15','2026-05-22 12:54:14','2026-06-16 06:44:16'),(4,3,'rahul','rahul@gmail.com','$2a$10$.rx5sudDEHJ6LnT2NxSC0eRXOxKSnGiKmPYExQkFGkMZARFq.kYg2','7972872262',NULL,1,'2026-06-15 08:25:45','2026-06-15 08:25:45','2026-06-15 08:25:45'),(5,3,'RC User','rc1781516449838@test.com','$2a$10$87QVZgfhMN184lmYhF5LouDeCbFZ2CMdBMOY6xwqOLwJ8yB719EdC',NULL,NULL,1,'2026-06-15 09:40:49','2026-06-15 09:40:49','2026-06-15 09:40:49'),(6,3,'RC User','rc1781516479259@test.com','$2a$10$QRHBLnJ2XBxQGPsSN/Gmj.CsMsG7gF3M3BvylBM0B9orE39VwFNxK',NULL,NULL,1,'2026-06-15 09:41:19','2026-06-15 09:41:19','2026-06-15 09:41:19'),(7,3,'RC User','rc1781516516028@test.com','$2a$10$TE8Abva3yVU.qy/T9qzeVuaYiUgPgt20k.XMfZU/TBC3fQWlTz4ci',NULL,NULL,1,'2026-06-15 09:41:56','2026-06-15 09:41:56','2026-06-15 09:41:56'),(8,3,'ramesh','ramesh@gmail.com','$2a$10$Vd5xE/8AikFaehhgUdZTR.PW7psdgCMEevAHj1b6fG/MTUDTU2ehi','8983900900',NULL,0,NULL,'2026-06-16 06:05:10','2026-06-16 07:09:00'),(9,2,'chetan ','chetan@gmail.com','$2a$10$xmCmv1p24abGx3/tQPstA.HUbwkHGY76AXmDgZbEsODRV7eW8z3kO','',NULL,1,NULL,'2026-06-16 06:06:55','2026-06-16 06:06:55'),(10,3,'Debug User','debug1891713493@test.com','$2a$10$HCgvFbzOB/pVSq9413mkPOfB7SvTDa5iHeSZocwKmeK/n.phTfDH.',NULL,NULL,1,'2026-06-16 06:17:28','2026-06-16 06:17:27','2026-06-16 06:17:28'),(11,3,'Reg Test','regtest1781590975429@test.com','$2a$10$ClNlblBIW0RXmHkZJxT17.4vTw0vO.R/wLZDbUcO37xsbwlADUBNS',NULL,NULL,1,'2026-06-16 06:22:55','2026-06-16 06:22:55','2026-06-16 06:22:55'),(12,3,'HTTP Test','httptest1758632164@test.com','$2a$10$RlWRkWd14ZJ0YE4idg7vQeGjKPs6qw1EoOHC/VTQvUrihwRbZl.o6',NULL,NULL,1,'2026-06-16 06:25:42','2026-06-16 06:25:42','2026-06-16 06:25:42'),(13,3,'Test','strpkg734529452@test.com','$2a$10$hETg.nk8f4/2KKN.UDV70.gYtPwkEipaYzK7z1g5.VdnX74pWP3SG',NULL,NULL,1,'2026-06-16 06:28:48','2026-06-16 06:28:48','2026-06-16 06:28:48'),(14,3,'Test','nophone1502914921@test.com','$2a$10$gu1csPWrlJvxdTSh7L1YoOxVkRiuHhiJ9RitQRTjG7H076VfYe2LG',NULL,NULL,1,'2026-06-16 06:28:52','2026-06-16 06:28:52','2026-06-16 06:28:52'),(15,3,'X','dup@test.com','$2a$10$RxG89z2NWlEgJqWRRN5C0ukfPIjez/1S/0OuCmGlpYqOqcn5lNclq',NULL,NULL,1,'2026-06-16 06:29:53','2026-06-16 06:29:52','2026-06-16 06:29:53'),(16,3,'Email Fail Test','emailfail1781591464119@test.com','$2a$10$8sGPvBtuWincfsPcuWtGLeqjingav1tpxoTTshDlJVwkX17LqI3gW',NULL,NULL,1,NULL,'2026-06-16 06:31:04','2026-06-16 06:31:04'),(17,3,'Verify Fix','verifyfix1260180273@test.com','$2a$10$iFuANw4WuvGKF899L85poOY6lXUEru08lxjIA5DKRX59y/d0kiMY2',NULL,NULL,1,'2026-06-16 06:35:58','2026-06-16 06:35:58','2026-06-16 06:35:58'),(18,2,'CRUD Trainer','crudtrainer1781592206898@test.com','$2a$10$cBcnD2xxIfPXisDpZMSgDu5Ye.XN2dW9N5jNqpArSR5kJYTCEFsHC',NULL,NULL,1,NULL,'2026-06-16 06:43:27','2026-06-16 06:43:27'),(19,3,'CRUD Student','crudstudent1781592207024@test.com','$2a$10$cGJg0UYCMmmDCkGIY0mS/.ts97SgwfVAgvkAP/I12RpP1XagNWz6O',NULL,NULL,1,NULL,'2026-06-16 06:43:27','2026-06-16 06:43:27'),(20,3,'CRUD Reg','crudreg1781592207249@test.com','$2a$10$2Bl499PfokgZBHA.ZMYAnOT/5YbW1KVPd5/teZ215u0XiEKQdAim.',NULL,NULL,1,'2026-06-16 06:43:27','2026-06-16 06:43:27','2026-06-16 06:43:27'),(21,3,'RC User','rc1781592255621@test.com','$2a$10$f1Ibep0uzN1lcabos0R4yO8tsF.3hTtNKZd0Wew8DxQYTFFcAAMBm',NULL,NULL,0,'2026-06-16 06:44:15','2026-06-16 06:44:15','2026-06-16 07:08:29'),(22,3,'tejas dex','tejasdex@gmail.com','$2a$10$WGrFvhW7ZPR.mgobYwwJv.ZGT5CMlNDe1ilBVvGLuRc10aEZ8x2VK','9989801912',NULL,1,'2026-06-16 07:15:00','2026-06-16 07:12:45','2026-06-16 07:15:00');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-17 11:31:59
